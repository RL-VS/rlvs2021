# bo_tutorial
Notebook for the Bayesian Optimization (quick) tutorial
