import connect4
import random

class AlphaBeta:
  def __init__(self, depth = 8):
    self.game = connect4.Game()
    self.depth = depth

  # returns a move based on an alpha-beta search
  def act(self):
    depth = 9 
    move = self.search()
    return move

  # update the internal board state for the class
  def feed(self, move):
    self.game.make_move(move)

  # the root node of an alpha-beta search
  def search(self):
    print("AlphaBeta searching")
    moves = self.game.moves()

    # a list to store the values associated with each move
    scores = []      
    alpha = -10
    for move in moves:
      res = self.game.make_move(move)
      # if the move wins the game, play it immediately
      if res:                     
        self.game.unmake_move()
        return move
      val = -self.alpha_beta(-10, -alpha, self.depth - 1)
      self.game.unmake_move()
      scores.append((val, move))

    # the algorithm randomises between moves that have the same value 
    random.shuffle(scores)
    scores.sort(key = lambda x: -x[0])
    print("AlphaBeta score: " + str(scores[0][0]))
    return scores[0][1]

 

  def alpha_beta(self, alpha, beta, depth):
    if depth == 0: return 0 
    moves = self.game.moves()
    # check whether or not the game is drawn
    if len(moves) == 0: return 0 
    for move in moves:
      res = self.game.make_move(move)
      # if the move wins the game, return a winning score
      if res:
        self.game.unmake_move()
        return 1 + 0.01 * depth
      val = -self.alpha_beta(-beta, -alpha, depth - 1)
      self.game.unmake_move()

      # check for alpha node
      if val >= alpha:
        alpha = val

      # check for beta cut
      if val >= beta:
        return val
    return alpha 






