import connect4
import mcts
import alpha_beta

# create a connect4 game
game = connect4.Game()

# create an MCTS and AlphaBeta player
player1 = alpha_beta.AlphaBeta(depth = 8)
player2 = alpha_beta.AlphaBeta(depth = 8)

# UNCOMMENT THIS TO TEST YOUR PLAYER
#player1 = mcts.MCTS(iterations = 20000)

# UNCOMMENT THIS TO TEST YOUR ROLLOUT FUNCTION
#player1 = mcts.MCTS(iterations = 20000)
#player1.test_rollout()
#exit(0)

# loop until the game is drawn
while len(game.moves()) > 0:
  game.show()

  # reverse these if you want MCTS to go first
  if game.turn == 1:
    move = player1.act()
  else:
    move = player2.act()

  # update the internal state of both players
  player1.feed(move)
  player2.feed(move)

  # if the move wins the game, then break
  if game.make_move(move):
    break
game.show() 


